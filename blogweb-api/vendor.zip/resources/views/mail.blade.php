<p>Hi, <br />Some one has submitted contact form.</p>
<p><strong>Name: </strong>{{$name}}</p>
<p><strong>Email: </strong>{{$email}}</p>
<p><strong>Phone: </strong>{{$phone}}</p>
<p><strong>Message: </strong>{{$messages}}</p>
<br />Thanks..
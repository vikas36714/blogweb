<p>Hi, <br />Some one has submitted contact form.</p>
<p><strong>Name: </strong><?php echo e($name); ?></p>
<p><strong>Email: </strong><?php echo e($email); ?></p>
<p><strong>Phone: </strong><?php echo e($phone); ?></p>
<p><strong>Message: </strong><?php echo e($messages); ?></p>
<br />Thanks..<?php /**PATH C:\xampp\htdocs\Angular-Projects\blog-website\api\resources\views/mail.blade.php ENDPATH**/ ?>
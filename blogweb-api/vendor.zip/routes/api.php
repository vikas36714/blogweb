<?php

use Illuminate\Http\Request;
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: X-PINGOTHER, Content-Type ");
header("Access-Control-Allow-Credentials", "true");
header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, X-Token-Auth, Authorization');
header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });



// Blog //

Route::get('blogs', 'Api\BlogController@index');
Route::get('blog/{id}', 'Api\BlogController@show');
Route::get('featured_blogs', 'Api\BlogController@featured_blogs');
Route::get('recent_blogs', 'Api\BlogController@recent_blogs');

// Category //

Route::get('categories', 'Api\CategoryController@index');
Route::get('category/{id}', 'Api\CategoryController@show');
Route::post('category', 'Api\CategoryController@store');
Route::put('category/{id}', 'Api\CategoryController@store');
Route::delete('category/{id}', 'Api\CategoryController@destroy');

// Page //

Route::get('page/{slug}', 'Api\PageController@index');
Route::get('page/{id}', 'Api\PageController@show');

// Contact and Send Email //

Route::post('contact', 'Api\ContactController@contact');

// Login //

Route::post('login', 'Api\AuthController@login');
Route::post('register', 'Api\AuthController@register');

Route::group(['middleware' => 'auth:api'], function(){
    
    // Admin Section //
    
    Route::get('adminblogs', 'Api\AdminBlogController@index');
    Route::get('adminblog/{id}', 'Api\AdminBlogController@show');
    Route::post('createblog', 'Api\AdminBlogController@store');
    Route::post('updateblog/{id}', 'Api\AdminBlogController@update');
    Route::delete('deleteblog/{id}', 'Api\AdminBlogController@destroy');
});



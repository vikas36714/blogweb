<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Blog;

class BlogController extends Controller
{
    public $successStatus = 200;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs = Blog::where('blogs.is_active', 1)
        ->join('users as user', 'blogs.user_id', '=', 'user.id')
        ->leftJoin('categories as category', 'blogs.category_id', '=', 'category.id')
        ->select('blogs.*','category.category_name','user.first_name','user.last_name')->get();
        foreach($blogs as $blog){
            //$blog['image'] = 'assets/images/'.$blog->image;
            $blog['image'] = url('blogs_images/'.$blog->image);
        }
        return response()->json($blogs, $this-> successStatus);
    }

    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $blogs = Blog::where('blogs.is_active', 1)
                        ->where('blogs.id', $id)
                        ->join('users as user', 'blogs.user_id', '=', 'user.id')
                        ->leftJoin('categories as category', 'blogs.category_id', '=', 'category.id')
                        ->select('blogs.*','category.category_name','user.first_name','user.last_name')
                        ->first();
        $blogs['image'] = url('blogs_images/'.$blogs->image);
                        
        return response()->json($blogs, $this-> successStatus);
    }



    public function featured_blogs()
    {
        $featured_blogs = Blog::where('blogs.is_active', 1)->where('blogs.is_featured', 1)
        ->join('users as user', 'blogs.user_id', '=', 'user.id')
        ->leftJoin('categories as category', 'blogs.category_id', '=', 'category.id')
        ->select('blogs.*','category.category_name','user.first_name','user.last_name')->get();
        foreach($featured_blogs as $featured_blog){
            $featured_blog['image'] = url('blogs_images/'.$featured_blog->image);
        }
        return response()->json($featured_blogs, $this-> successStatus);
    }

    public function recent_blogs()
    {
        $recentposts = Blog::where('blogs.is_active', 1)
                            ->orderBy('blogs.created_at', 'desc')
                            ->take(5)
                            ->join('users as user', 'blogs.user_id', '=', 'user.id')
                            ->leftJoin('categories as category', 'blogs.category_id', '=', 'category.id')
                            ->select('blogs.*','category.category_name','user.first_name','user.last_name')->get();
        foreach($recentposts as $recentpost){
            $recentpost['image'] = url('blogs_images/'.$recentpost->image);
            
        }
        return response()->json($recentposts, $this-> successStatus);
    }



}

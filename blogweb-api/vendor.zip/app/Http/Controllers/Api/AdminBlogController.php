<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Blog;
use Image;
use Auth;
use App\User;
use File;

class AdminBlogController extends Controller
{
    public $successStatus = 200;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $blogs = Blog::join('users as user', 'blogs.user_id', '=', 'user.id')
        ->select('blogs.*','user.first_name','user.last_name')
        ->orderBy('blogs.id', 'desc')
        ->get();
        foreach($blogs as $blog){
            $blog['image'] = url('blogs_images/'.$blog->image);
        }
        return response()->json($blogs, $this-> successStatus);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // $this->validate($request, [
        //     'image'  => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        //    ]);

        if ($request->hasFile('image')) {
            
            $image = $request->file('image');
            
            $image_name = time() . '.' . $image->getClientOriginalExtension();
            
            // $destinationPath = public_path('/thumbnail');
            
            // $resize_image = Image::make($image->getRealPath());
            // $resize_image->resize(150, 150, function($constraint)
            // {
            //     $constraint->aspectRatio();
               
            // })->save($destinationPath . '/' . $image_name);
            $destinationPath = public_path('/blogs_images');
            
            $image->move($destinationPath, $image_name);
            
        }
        
        $blog = new Blog;
        $blog->title = $request->title;
        $blog->image = $image_name;
        $blog->description = $request->description;
        $blog->user_id = Auth::user()->id;
        $blog->is_featured = $request->is_featured;
        $blog->is_active = $request->is_active;
        $blog->save();
        return response()->json(['success' => $blog->id], $this-> successStatus);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $blog = Blog::where('blogs.id', $id)
                ->select('blogs.*', 'users.first_name','users.last_name')
                ->join('users', 'users.id', '=', 'blogs.id')->first();
        $blog['image'] = url('blogs_images/'.$blog->image);
        return response()->json($blog, $this-> successStatus);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        // $this->validate($request, [
        //     'image'  => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        //    ]);
        
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image_name = time() . '.' . $image->getClientOriginalExtension();
            
            // $destinationPath = public_path('/thumbnail');
            
            // $resize_image = Image::make($image->getRealPath());
            // $resize_image->resize(150, 150, function($constraint)
            // {
            //     $constraint->aspectRatio();
               
            // })->save($destinationPath . '/' . $image_name);
            $destinationPath = public_path('/blogs_images');
            
            $image->move($destinationPath, $image_name);
            
        }
        
            $blog = Blog::find($id);
            $blog->title = $request->title;
            $blog->image = $image_name;
            $blog->description = $request->description;
            $blog->user_id = Auth::user()->id;
            $blog->is_featured = $request->is_featured;
            $blog->is_active = $request->is_active;
            $blog->save();
            return response()->json(['success' => $blog->id], $this-> successStatus);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $blog = Blog::find($id);
        $file= $blog->image;
        $filename = public_path().'/blogs_images/'.$file;
        File::delete($filename);
        $blog->delete();
        return response()->json(['success' => 'Blog deleted'], $this-> successStatus);
    }
}
